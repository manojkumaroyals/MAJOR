from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('form.html')

@app.route('/submit', methods=['POST'])
def submit():
    if request.method == 'POST':
        form_data = request.form
        name = form_data['name']
        email = form_data['email']
        print(f"Name: {name}, Email: {email}")
        return "Form submitted successfully"

if __name__ == '__main__':
    app.run(debug=True)
